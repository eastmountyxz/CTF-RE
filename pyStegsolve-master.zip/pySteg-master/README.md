pySteg
======

pySteg is a simple GUI frontend for the steghide (steganography) console application inspired by the Steghide UI from "Drunken Canadian" for Windows.
